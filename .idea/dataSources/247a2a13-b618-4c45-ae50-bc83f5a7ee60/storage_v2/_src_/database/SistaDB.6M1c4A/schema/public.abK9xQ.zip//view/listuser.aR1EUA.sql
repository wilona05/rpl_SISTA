create view listuser(noinduk, nama, email, passwords) as
SELECT mahasiswa.npm AS noinduk,
       mahasiswa.nama,
       mahasiswa.email,
       mahasiswa.passwords
FROM mahasiswa
UNION ALL
SELECT dosen.nip AS noinduk,
       dosen.nama,
       dosen.email,
       dosen.passwords
FROM dosen
UNION ALL
SELECT '0'::character varying     AS noinduk,
       'admin'::character varying AS nama,
       admins.email,
       admins.passwords
FROM admins;

alter table listuser
    owner to postgres;

